import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { igame } from './game';
import { NgIf } from '@angular/common';


@Injectable({
  providedIn: 'root'
})
export class GameService {
  userId:number;
  userName:string;
  displayName:boolean;

  gameList:Array<igame>[];
  userAmount:number=600;
  url="/assets/game.json";

  
  constructor(private http:HttpClient) {
    this.getGameList().subscribe(data=>this.gameList=data);
   }
   getGameList():any{
    return this.http.get<igame>(this.url);
  }

  played(game){
    console.log(game);
    this.userName=game.name;
    this.userId=game.price;
    if(this.userAmount>=game.price)
    {
      this.userAmount=this.userAmount-game.price;
      this.displayName=true;
    }
    
      else{
      alert("You dont have enough balance to play this game");
      this.displayName=false;
    }
  }
}
