export class igame{
  
    name:string;
    price:number;
   
} 