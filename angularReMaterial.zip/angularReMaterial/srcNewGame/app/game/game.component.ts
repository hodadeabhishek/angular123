import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {

  constructor(private service:GameService) { }

  ngOnInit() {
  }
  play=false;
  setUserDetails(data){
    if(data.userName==""||data.userAddress==""||data.userAmount==undefined){
      alert("Please fill the form")
    }
    else{
    alert("You can start playing now!!!")
    this.service.setUserDetails(data);
    this.play=true;
    }
    
  }
}
