import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import { igame } from '../game';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  gamearr: igame[];
  isUpdate : boolean=true;
  name: String;
  price:number;
  constructor(private service:GameService) { }

  ngOnInit() {
  
    this.service.getGameList().subscribe(data=>this.gamearr=data);
  }
  played(game){
    this.service.played(game);
  }

  delete(game:igame){


    let arr=this.gamearr.filter(p=>p.name!=game.name);
    this.gamearr=arr;
    console.log(this.gamearr);
  }

  update(game : igame){
    
    this.name=game.name;
    this.price=game.price;
    this.isUpdate=true;
    console.log("this is update")
   
  }
  updateDetails(){
    let arr=this.gamearr.filter(p=>p.name!=this.name);
    arr.push({name:this.name,price:this.price});
    this.gamearr=arr;
    this.isUpdate=false;
    console.log("this is update Detail")
  }
}
