export class igame{
  
    name:String;
    price:number;
   
} 