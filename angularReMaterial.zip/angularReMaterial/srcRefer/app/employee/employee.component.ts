import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
employees : IEmployee[ ] =[{
  eid : 1001,ename : 'rkr',esal : 50000
},{
  eid : 1002,ename : 'sri',esal : 50000
}]; 

  constructor() { }

  ngOnInit() {
  }
delete(emp : IEmployee){
  let arr=this.employees.filter(p=>p.eid!=emp.eid);
this.employees=arr;
}
}
