export interface IEmployee{
    eid : number;
    ename : String;
    esal : number;
}