import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { DepartmentComponent } from './department/department.component';
import { Route, RouterModule } from '@angular/router';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';
import { BookComponent } from './book/book.component';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
const routes:Route[]=[{
path:'user',
component:UserComponent
},{
path:'book',
component:BookComponent
},{
  path:'empdetail/:id',
  component: EmployeedetailsComponent
},{
  path : 'emp',
  component : EmployeeComponent
},{
  path : 'dept',
  component : DepartmentComponent
},{
  path:'',
  redirectTo:'emp',
  pathMatch:'full'
},{
  path:'**',
  component:EmployeeComponent
}];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    DepartmentComponent,
    EmployeedetailsComponent,
    BookComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
