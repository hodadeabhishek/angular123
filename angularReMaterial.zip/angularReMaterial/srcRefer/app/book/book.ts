export interface IBook{
    id:number;
    title:String;
    year:number;
    author:String;
}