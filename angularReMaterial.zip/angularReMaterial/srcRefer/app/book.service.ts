import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IBook } from './book/book';
@Injectable({
  providedIn: 'root'
})
export class BookService {

  book:IBook;
url:string="assets/booklist.json";
  constructor(private http : HttpClient) { 
      this.getBooks().subscribe(data=>this.book=data); 
    }
  getBooks() :any{
return this.http.get<IBook >(this.url);    
  }
}

