package com.cg.paymentWallet.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.paymentWallet.bean.PaymentAccount;
import com.cg.paymentWallet.bean.PaymentTransaction;
import com.cg.paymentWallet.dao.PaymentAccountRepository;
import com.cg.paymentWallet.dao.PaymentTransactionRepository;

import oracle.net.aso.a;

@Service
public class PaymentAccountService {

	@Autowired
	PaymentAccountRepository repoAccount;
	@Autowired
	PaymentTransactionRepository repoTr;

	Optional<PaymentAccount> option;
	PaymentTransaction transaction;
	PaymentAccount account;

	public String addAccount(PaymentAccount account1) {
		account1.setDateCreated(Date.valueOf(LocalDate.now()));
		account1.setWallet(0d);
		repoAccount.save(account1);
		addTransaction(account1,account1.getBalance(),"account created");
		return "your Account Id is: "+account1.getId();
	}


	public PaymentAccount getAccount(PaymentAccount account1) {

		option =repoAccount.findById(account1.getId());
		if(option.isPresent())
			return option.get();
		return null;
	}


	public PaymentAccount deposit(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);
		addTransaction(account,amount,"credited to account");
		return account;
	}

	public PaymentAccount withdraw(double amount, int id) {

		account=repoAccount.findById(id).get();
		account.setBalance(account.getBalance()-amount);
		repoAccount.save(account);

		addTransaction(account,amount,"deposited from account");
		return account;
	}


	public PaymentAccount bankToWallet(double amount, int id) {
		account=repoAccount.findById(id).get();
		if(account.getBalance()>=amount) {
			account.setBalance(account.getBalance()-amount);
			account.setWallet(account.getWallet()+amount);
			repoAccount.save(account);

			addTransaction(account,amount,"added in wallet");
		}
		return account;
	}


	public PaymentAccount walletToWallet(double amount, int id, int receiver) {

		account=repoAccount.findById(id).get();
		option=repoAccount.findById(receiver);
		PaymentAccount receiveAccount=option.get();
		receiveAccount.setWallet(receiveAccount.getWallet()+amount);
		account.setWallet(account.getWallet()-amount);
		repoAccount.save(account);
		repoAccount.save(receiveAccount);
		addTransaction(receiveAccount,amount,"received in wallet");

		addTransaction(account,amount,"paid from wallet");
		return account;
	}


	public boolean isAccount(int id) {
		option=repoAccount.findById(id);
		if(option.isPresent()) 
			return true;
		else
			return false;
	}


	public PaymentAccount walletToBank(double amount, int id) {
		account=repoAccount.findById(id).get();
		account.setWallet(account.getWallet()-amount);
		account.setBalance(account.getBalance()+amount);
		repoAccount.save(account);

		addTransaction(account,amount,"wallet to bank");
		return account;
	}
	
	public void addTransaction(PaymentAccount account1,Double amount,String operation) {
		transaction=new PaymentTransaction(account1.getId(), Date.valueOf(LocalDate.now()), account1.getBalance(), amount, account1.getWallet(), operation);
		repoTr.save(transaction);
	}
	
	public List<PaymentTransaction> getTransactions(int id) {
		List<PaymentTransaction> list = new ArrayList<PaymentTransaction>();
		repoTr.findAll().forEach(list::add);
		list=list.stream().filter(trans->trans.getAccountId()==id).collect(Collectors.toList());
		
		return list;
	}
}
