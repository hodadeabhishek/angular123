package com.cg.paymentWallet.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.paymentWallet.bean.PaymentAccount;
import com.cg.paymentWallet.bean.PaymentTransaction;
import com.cg.paymentWallet.service.PaymentAccountService;

@Controller
public class HomeController {


	@Autowired
	PaymentAccountService servAccount;

	PaymentAccount account;

	@RequestMapping("/")
	public String check(Model model) {
		model.addAttribute("account",new PaymentAccount());
		return "index";
	}


	@PostMapping("login")
	public String validateLogin(@ModelAttribute("account") PaymentAccount account1, Model model) {
		account=servAccount.getAccount(account1);

		if(account!=null)
		{
			if(account.getPassword().equals(account1.getPassword())) {
				model.addAttribute("account",account);
				return "homepage";
			}
			else {
				model.addAttribute("message","Wrong Password");
				return "index";
			}
		}
		else{
			model.addAttribute("message","Wrong Account Number");
			return "index";
		}
	}

	@RequestMapping("homepage")
	public String showHome(Model model) {

		model.addAttribute("account",account);
		return "homepage";
	}

	@RequestMapping("signup")
	public String signUp(Model model){
		model.addAttribute("account",new PaymentAccount());		
		return "signuppage";
	}

	@PostMapping("newaccount")
	public String newAccount(@ModelAttribute("account") PaymentAccount account, Model model ) {

		model.addAttribute("message",servAccount.addAccount(account));
		return "index";

	}
	
	@RequestMapping("show")
	public String show(Model model)
	
	{
		model.addAttribute("account",account);
		return "show";
	}

	@RequestMapping("deposit")
	public String deposit(Model model)
	{

		return "deposit";
	}


	@PostMapping("depositAmount")
	public String depositAmount(@RequestParam double amount, Model model)
	{

		account=servAccount.deposit(amount,account.getId());
		model.addAttribute("account", account);
		model.addAttribute("message","Successfull");
		return "deposit";
	}

	@RequestMapping("withdraw")
	public String withdraw(Model model)
	{

		return "withdraw";
	}


	@PostMapping("withdrawAmount")
	public String withdrawAmount(@RequestParam double amount, Model model)
	{
		model.addAttribute("account", account);
		if(account.getBalance()>=amount) {
			account=servAccount.withdraw(amount,account.getId());
			model.addAttribute("account", account);

			model.addAttribute("message","Successfull");
		}
		else {
			

			model.addAttribute("message","Could not complete transaction");
		}
		return "withdraw";
	}
	@RequestMapping("addToWallet")
	public String bankToWallet(Model model)
	{

		return "bankToWallet";
	}


	@PostMapping("bankToWallet")
	public String bankToWallet(@RequestParam double amount, Model model)
	{
		model.addAttribute("account", account);
		if(account.getBalance()>=amount) {
			account=servAccount.bankToWallet(amount,account.getId());
			model.addAttribute("account", account);

			model.addAttribute("message","Successfull");
		}
		else {
			

			model.addAttribute("message","Could not complete transaction");
		}
		return "bankToWallet";
	}
	
	@RequestMapping("payFromWallet")
	public String payFromWallet(Model model)
	{

		return "payFromWallet";
	}


	@PostMapping("walletToWallet")
	public String bankToWallet(@RequestParam double amount,@RequestParam int receiver, Model model)
	{
		model.addAttribute("account", account);
		if(account.getWallet()>=amount) {
			if(servAccount.isAccount(receiver)) {
			account=servAccount.walletToWallet(amount,account.getId(),receiver);
			model.addAttribute("account", account);

			model.addAttribute("message","Successfull");
			}
			else
				model.addAttribute("message","Receivers ID is not valid");
		}
		else {
			

			model.addAttribute("message","Could not complete transaction due to low balance");
		}
		return "payFromWallet";
	}
	

	@RequestMapping("walletToBank")
	public String walletaToBank(Model model)
	{

		return "walletToBank";
	}


	@PostMapping("transferBackToBank")
	public String walletaToBankTransfer(@RequestParam double amount,Model model)
	{
		model.addAttribute("account", account);
		if(account.getWallet()>=amount) {{
			account=servAccount.walletToBank(amount,account.getId());
			model.addAttribute("account", account);
			model.addAttribute("message","Successfull");
			}
			
		}
		else {
			model.addAttribute("message","Could not complete transaction due to low wallet balance");
		}
		return "walletaToBank";
	}
	
	@RequestMapping("transaction")
	public String transaction(Model model) {

		List<PaymentTransaction> list=servAccount.getTransactions(account.getId());
		model.addAttribute("transactions",list);
		model.addAttribute("trans",new PaymentTransaction());
		model.addAttribute("id",account.getId());
		return "transactionPage";
	}
	
	
}
