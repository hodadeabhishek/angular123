package com.cg.paymentWallet.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.paymentWallet.bean.PaymentTransaction;

@Repository
public interface PaymentTransactionRepository extends CrudRepository<PaymentTransaction,Integer>{
	
	Iterable<PaymentTransaction> findAllByAccountId(int accountId);

}
