package com.cg.paymentWallet.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.paymentWallet.bean.PaymentAccount;

@Repository
public interface PaymentAccountRepository extends CrudRepository<PaymentAccount,Integer>{

}
