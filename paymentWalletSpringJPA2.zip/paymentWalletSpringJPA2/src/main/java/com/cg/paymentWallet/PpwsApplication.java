package com.cg.paymentWallet;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


import com.cg.paymentWallet.service.SJAccountService;

@SpringBootApplication
/*@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})*/
public class PpwsApplication extends SpringBootServletInitializer implements CommandLineRunner{

	@Autowired
	SJAccountService servAccount;
	
	public SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(PpwsApplication.class);
		
	}
	public static void main(String[] args) {
		
		
		SpringApplication.run(PpwsApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		/*SJAccount a=new SJAccount();
		a.setId(1);
		a.setName("Ritesh");
		a.setContact("9011187405");
		a.setPassword("1");
		a.setBalance((double) 5000);
		a.setDateCreated(Date.valueOf(LocalDate.now()));
		a.setWallet(100d);
		servAccount.addAccount(a);*/
	}

}
