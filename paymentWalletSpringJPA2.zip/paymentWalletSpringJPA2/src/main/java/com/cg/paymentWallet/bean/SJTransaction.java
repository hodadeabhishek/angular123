package com.cg.paymentWallet.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SJTransaction {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private int accountId;
	private Date tDate;

	private double balance;
	private double amount;
	private double wallet;
	private String operation;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public Date gettDate() {
		return tDate;
	}
	public void settDate(Date tDate) {
		this.tDate = tDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getWallet() {
		return wallet;
	}
	public void setWallet(double wallet) {
		this.wallet = wallet;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	@Override
	public String toString() {
		return "SJTransaction [id=" + id + ", accountId=" + accountId + ", tDate=" + tDate + ", balance=" + balance
				+ ", amount=" + amount + ", wallet=" + wallet + ", operation=" + operation + "]";
	}
	
	public SJTransaction(int accountId, Date tDate, double balance, double amount, double wallet,
			String operation) {
		super();
		this.accountId = accountId;
		this.tDate = tDate;
		this.balance = balance;
		this.amount = amount;
		this.wallet = wallet;
		this.operation = operation;
	}
	public SJTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
}
